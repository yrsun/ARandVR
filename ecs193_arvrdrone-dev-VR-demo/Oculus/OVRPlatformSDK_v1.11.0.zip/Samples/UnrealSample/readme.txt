You will need to edit the Config\DefaultEngine.ini file and update the AppID.  Look for this section:
[OnlineSubsystemOculus]
bEnabled=true
OculusAppId=1025875484134790

