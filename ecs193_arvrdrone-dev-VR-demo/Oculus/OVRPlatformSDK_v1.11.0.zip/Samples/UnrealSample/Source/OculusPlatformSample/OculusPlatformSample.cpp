// @generated

#include "OculusPlatformSample.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, OculusPlatformSample, "OculusPlatformSample" );
