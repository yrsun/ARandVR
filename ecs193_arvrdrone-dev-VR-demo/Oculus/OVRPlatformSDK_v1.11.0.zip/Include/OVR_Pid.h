// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

#ifndef OVR_PID_H
#define OVR_PID_H

#include "OVR_Platform_Defs.h"
#include <stddef.h>

typedef struct ovrPid *ovrPidHandle;

OVRP_PUBLIC_FUNCTION(const char *) ovr_Pid_GetId(const ovrPidHandle obj);

#endif
